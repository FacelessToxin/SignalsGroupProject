function FrequencyAnalysis(signal, fs, spectralResolution, windowType, overlap,xScale,yScale)

    % FrequencyAnalysis performs DFT and STFT on an input signal and plots the results in subplots.
        
    % Inputs:
    %   signal            - (array) Audio signal data
    %   fs                - (scalar) Sampling frequency in Hz
    %   spectralResolution - (scalar) Desired spectral resolution in Hz for STFT
    %   windowType        - (string) Type of window: 'hann', 'hamming', 'rect' for STFT
    %   overlap           - (scalar) Overlap percentage for STFT - should be 50
    %
    % Outputs:
    %   Plots DFT and STFT magnitude spectrum in subplots and provides guidance on method selection.

    % Evaluate signal characteristics
    signalVariability = std(diff(signal)); % Standard deviation of signal differences
    isStationary = signalVariability < 0.1; % Arbitrary threshold for stationarity

    % Display information about the signal's characteristics
    if isStationary
        disp('The signal is relatively stationary; DFT is likely more useful.');
    else
        disp('The signal is non-stationary; STFT is likely more useful.');
    end

    % DFT Analysis
    N = length(signal);             % Length of the signal
    f_dft = (0:N-1) * (fs / N);     % Frequency vector for DFT
    X = fft(signal);                % Compute DFT
    dftMagnitude = abs(X(1:floor(N/2))); % Magnitude of DFT for positive frequencies

    % Determine window length based on desired spectral resolution
    windowLength = round(fs / spectralResolution);
    if windowLength > length(signal)/2
        windowLength = length(signal)/2;
    end

    % Set up the window based on the specified type
    switch windowType
        case 'hann'
            win = hann(windowLength);
        case 'hamming'
            win = hamming(windowLength);
        case 'rect'
            win = rectwin(windowLength);
        otherwise
            error('Invalid window type. Choose from "hann", "hamming", or "rect".')
    end

    % Calculate the overlap in samples
    overlapSamples = round((overlap / 100) * windowLength);

    % Create a new figure
    figure;

    % Subplot for DFT
    subplot(2, 1, 1); % 2 rows, 1 column, first subplot
    plot(f_dft(1:floor(N/2)), dftMagnitude, 'b'); % DFT in blue
    xlim([0 fs/2]); % Limit x-axis to half the sampling frequency
    xlabel('Frequency (Hz)');
    ylabel('Magnitude');
    title('DFT Magnitude Spectrum');
    grid on; % Add grid

    % % Check if there should be used linear og logarithmic scalins
    % if strcmp(xScale, 'log')
    %     set(gca, 'XScale', 'log');
    % elseif strcmp(xScale, 'lin')
    %     set(gca, 'XScale', 'linear');
    % end

    % Perform STFT
    [S, f_stft, t_stft] = stft(signal, fs, 'Window', win, 'OverlapLength', overlapSamples, 'FFTLength', windowLength);
    
    % Create Subplot for STFT Spectrogram
    subplot(2, 1, 2); % 2 rows, 1 column, second subplot
    imagesc(t_stft, f_stft, 20*log10(abs(S))); % Use decibel scale for magnitude
    axis xy; % Invert y-axis to have lower frequencies at the bottom
    xlabel('Time (s)');
    ylabel('Frequency (Hz)');
    title('Spectrogram of the Signal');
    colorbar; % Show color bar indicating intensity
    grid on; % Add grid

    % Seems like there was an error with getting log stuff...
    % if strcmp(yScale, 'log')
    %     set(gca, 'YScale', 'log');
    % elseif strcmp(yScale, 'lin')
    %     set(gca, 'YScale', 'linear'); 
    % end
end
