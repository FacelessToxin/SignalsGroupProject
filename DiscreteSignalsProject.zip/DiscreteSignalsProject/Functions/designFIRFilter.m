function b = designFIRFilter(order, filterType, cutoffFreq, fs, windowType)
    % DESIGNFIRFILTER Designs an FIR filter based on specified parameters.
    %
    % Inputs:
    %   - order: Filter_Order (integer)
    %   - filterType: (filter)Type ('low', 'high', 'bandpass', 'stop')
    %   - cutoffFreq: Cut_off (Lower/Upper boundaries, Hz)
    %   - fs: Sampling_Frequency (Hz)
    %   - windowType: Window_Type (e.g., 'hamming', 'hann', 'blackman', 'rectangular')
    % Output:
    %   - b: Numerator coefficients of the FIR filter (Feedforward)
    
    % Normalize cutoff frequencies to the Nyquist frequency
    nyquist = fs / 2;
    normCutoff = cutoffFreq / nyquist;
    
    % Choose the window based on the input windowType
    switch lower(windowType)
        case 'hamming'
            win = hamming(order+1);
        case 'hann'
            win = hann(order+1);
        case 'rect'
            win = rectwin(order+1);
        otherwise
            error('There was an issue with the windowtype, check spellings!');
    end
    
    % Design the filter using fir1 with the specified window
    b = fir1(order, normCutoff, filterType, win);
end
