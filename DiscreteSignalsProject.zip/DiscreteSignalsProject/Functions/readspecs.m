function Spec_List = readspecs(spec_file_name)
    % This function is ment to read the global specs, There will be changes
    % so do follow the code description
    
    % Open the SpecFile
    spec_file = fopen(spec_file_name, 'r');
    if spec_file == -1
        error('There was an error, please provide the appropriate format');
    end
    
    % Empty List
    Spec_List = {};
    
    Current_Line = fgetl(spec_file);
    while ischar(Current_Line)
        % Skip lines that are empty or start with '%'
        if ~isempty(strtrim(Current_Line)) && strtrim(Current_Line(1)) == '%'
            Current_Line = fgetl(spec_file);
            continue;
        end
        % Append the Spec
        Spec_List{end+1} = Current_Line;  % Add the line to the end of the cell array
        Current_Line = fgetl(spec_file);
    end

    fclose(spec_file);
    
    % If Bastian forgot to remove empty lines, remove 0x0 characters from
    % the list
    Spec_List = Spec_List(~cellfun('isempty', Spec_List));

end