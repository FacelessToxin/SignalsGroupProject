function [signal, t] = SigGenerator(type, fs, duration, periodicity, frequencies)
    % SignalGenerator generates different types of signals based on input parameters
    %
    % Inputs:
    %   type        - (string) Type of signal ('rect', 'tone', 'tone-complex', 'noise')
    %   fs          - (scalar) Sampling frequency in Hz
    %   duration    - (scalar) Duration of the signal in seconds
    %   periodicity - (scalar) Period for rectangular wave (only for 'rect' type)
    %   frequencies - (array) Frequencies for tone or tone-complex
    %
    % Outputs:
    %   toneSignal - (array) Generated tone signal
    %   t          - (array) Time vector corresponding to the tone signal

    % Time vector
    t = 0:1/fs:duration;
    
    % Signal generation based on type
    switch type
        case 'rect'
            rectSignal = square(2*pi*(1/Periodicity)*t);
        case 'tone'
            signal = sin(2 * pi * frequencies(1) * t); % Should only use the first frequency in frequencies)
        case 'tone-complex'
            signal = sum(sin(2 * pi * frequencies' * t), 1); % Should use all the frequencies
        case 'noise'
            signal = randn(1, length(t)); 
        otherwise
            error('Please check if the spelling matches the provided type!')
    end

    % Emergency zero padding
    if length(signal) > length(t)
        signal(end) = [];
    end
end