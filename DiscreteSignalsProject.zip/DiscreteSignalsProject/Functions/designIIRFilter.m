function [b, a] = designIIRFilter(order, method, filterType, cutoffFreq, fs)
    % DesignIIRFilter creates an IIR filter based on specified parameters.
    %
    % Inputs:
    %   - order: Filter_Order (integer)
    %   - method: Approximator ('butter', 'cheby1', 'cheby2','ellip')
    %   - filterType: (filter)Type ('low', 'high', 'bandpass', 'stop')
    %   - cutoffFreq: Cut_off (Lower/Upper boundaries , Hz)
    %   - fs: Sampling_Frequency (Hz)
    % Outputs:
    %   - b: Numerator coefficients of the IIR filter (Feedforward)
    %   - a: Denominator coefficients of the IIR filter (Feedbackwards)

    % Normalize cutoff frequencies to the Nyquist frequency
    nyquist = fs / 2;
    normCutoff = cutoffFreq / nyquist;

    % Ripple and Attenuation
    % It might be an idea to add this to the function, just for certainties
    % sake, but for now I have decided to just make it constants inside of
    % the function
    ripple = 0.5;
    stopbandAttenuation = 20;

    % Design the filter based on the chosen method and filter type
    switch method
        case 'butterworth'
            [b, a] = butter(order, normCutoff, filterType);
            
        case 'chebychevI'
            [b, a] = cheby1(order, ripple, normCutoff, filterType);

        case 'chebychevII'
            [b, a] = cheby2(order, stopbandAttenuation, normCutoff, filterType);

        case 'cauer'
            [b, a] = ellip(order, ripple, stopbandAttenuation, normCutoff, filterType);
            
        otherwise
            error('Error in the provided filter type, please check the spelling: butter, cheby1, cheby2, ellip, and make sure it is string');
    end
end
