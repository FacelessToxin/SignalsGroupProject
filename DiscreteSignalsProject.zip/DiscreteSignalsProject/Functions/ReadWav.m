function [Signal, fs] = ReadWav(filePath, targetFs)
    % ReadWav Reads a .wav file and resamples the signal to the target sampling frequency.
    %
    % Inputs:
    %   filePath  - (string) Path to the .wav file
    %   targetFs  - (scalar) Target sampling frequency (Hz)
    %
    % Outputs:
    %   Signal    - (array) Audio data read and resampled to targetFs
    %   fs        - (scalar) Sampling frequency of the audio file (Hz)
    
    % Check if file exists
    if ~isfile(filePath)
        error('File not found. Please check the file path.');
    end
    
    % Read the .wav file
    [audioData, fs] = audioread(filePath);

    % Check for aliasing 
    if fs < 2 * max(abs(audioData)) 
        warning('Warning - aliasing!');
    end
    
    % If the sampling frequency is different from the target, resample the signal
    if fs ~= targetFs
        % Resample the signal
        audioData = resample(audioData, targetFs, fs);
        fs = targetFs; % Update fs to reflect the new sampling frequency
    end
    
    % output signal
    Signal = audioData;
end
