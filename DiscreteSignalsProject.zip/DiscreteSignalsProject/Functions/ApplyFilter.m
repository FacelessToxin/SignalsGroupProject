function [filteredSignal] = ApplyFilter(b,a, signal)
    % ApplyFilter Filters an input signal using given filter coefficients.
    %
    % Inputs:
    %   a      - (array) Denominator coefficients of the filter (a's)
    %   b      - (array) Numerator coefficients of the filter (b's)
    %   inputSignal  - (array) Input signal to be filtered
    %
    % Outputs:
    %   filteredSignal - (array) Filtered output signal

    % check inputs
    if nargin ~= 3
        error('Lacking inputs.');
    end

    if isempty(a) || isempty(b)
        error('Missing Filter');
    end

    if isempty(signal)
        error('We need to convolve something');
    end

    % Apply the filter 
    filteredSignal = filter(b, a, signal);


end