function zdomainplot(zeros, poles)
    % Uses zplane on some zeros and poles to plot
    %
    % Inputs:
    %   arrays
    
    % Plot the zeros and poles using the zplane function
    figure;
    zplane(zeros, poles);

end