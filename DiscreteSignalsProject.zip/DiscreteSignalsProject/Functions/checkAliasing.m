function Cut_Off = checkAliasing(fs, Cut_Off)
    % checkAliasing Checks if the cutoff frequency causes aliasing based on the sampling frequency
    %
    % Inputs:
    %   fs      - (scalar) Sampling frequency of the signal
    %   Cut_Off - (scalar) Cutoff frequency of the filter
    %
    % Output:
    %   Cut_Off - (scalar) Adjusted cutoff frequency if aliasing is detected

    % Nyquist frequency
    Nyquist_Frequency = fs / 2;
    
    % Margin to avoid aliasing
    margin = Nyquist_Frequency * 0.01; 

    % Check for possible aliasing
    if Cut_Off > (Nyquist_Frequency-margin)
        % Aliasing may occur, adjust the cutoff frequency
        warning('Aliasing may occur! The Cutoff has been reduced.');
        Cut_Off = Nyquist_Frequency-margin; % Adjust the cutoff frequency
    else
        % No aliasing detected
        disp('No aliasing detected.');
    end
end
