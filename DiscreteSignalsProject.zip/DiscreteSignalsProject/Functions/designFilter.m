function [b, a, combinedPlot] = designFilter(Filtering, order, method, filterType, cutoffFreq, fs, WindowType)
    % DESIGNFILTER Designs a filter (IIR or FIR) and generates a combined visualization.
    %
    % Inputs:
    %   - Filtering: 'iir' or 'fir' to select the type of filter design
    %   - order: Filter order (integer)
    %   - method: Approximator for IIR filter (e.g., 'butter', 'cheby1', etc.)
    %             Use empty ('') for FIR filters.
    %   - filterType: Filter type ('low', 'high', 'bandpass', 'stop')
    %   - cutoffFreq: Cutoff frequency/frequencies (Hz)
    %   - fs: Sampling frequency (Hz)
    %
    % Outputs:
    %   - b: Numerator coefficients of the designed filter
    %   - a: Denominator coefficients (only for IIR filters; for FIR, a=1)
    %   - combinedPlot: Handle to the combined plot with subplots

    % Design filter based on the Filtering variable
    if strcmp(Filtering, 'iir')
        [b, a] = designIIRFilter(order, method, filterType, cutoffFreq, fs);
    elseif strcmp(Filtering, 'fir')
        %windowType = 'hamming'; % Default window type for FIR filters
        b = designFIRFilter(order, filterType, cutoffFreq, fs, WindowType);
        a = 1; % For FIR filters, a = 1
    else
        error('Invalid Filtering type. Use "iir" or "fir".');
    end

    % Compute poles and zeros
    poles = roots(a);
    zeros = roots(b);

    % Create combined figure
    combinedPlot = figure;

    % Subplot 1: Pole-Zero Diagram
    subplot(2, 2, 1);
    hold on;
    plot(real(zeros), imag(zeros), 'o', 'MarkerSize', 8, 'MarkerEdgeColor', 'b', 'MarkerFaceColor', 'b'); % Zeros
    plot(real(poles), imag(poles), 'x', 'MarkerSize', 10, 'MarkerEdgeColor', 'r', 'LineWidth', 1.5); % Poles
    theta = linspace(0, 2*pi, 1000);
    plot(cos(theta), sin(theta), '--k', 'LineWidth', 1.2); % Unit circle
    xlabel('Real Part');
    ylabel('Imaginary Part');
    title('Pole-Zero Diagram');
    axis equal;
    grid on;
    hold off;

    % Subplot 2: Transfer Function Magnitude Response
    subplot(2, 2, 2);
    [h, f] = freqz(b, a, 1024, fs); % Compute frequency response
    plot(f, 20*log10(abs(h)), 'b', 'LineWidth', 1.5); % Magnitude response in dB
    xlabel('Frequency (Hz)');
    ylabel('Magnitude (dB)');
    title('Transfer Function Magnitude Response');
    grid on;

    % Compute impulse response
    impulseResponse = impz(b, a, 1024);

    % Subplot 3: Real Part of Impulse Response
    subplot(2, 2, 3);
    plot(real(impulseResponse), 'r', 'LineWidth', 1.5); % Real part
    xlabel('Samples');
    ylabel('Amplitude');
    title('Real Part of Impulse Response');
    grid on;

    % Subplot 4: Imaginary Part of Impulse Response
    subplot(2, 2, 4);
    plot(imag(impulseResponse), 'b', 'LineWidth', 1.5); % Imaginary part
    xlabel('Samples');
    ylabel('Amplitude');
    title('Imaginary Part of Impulse Response');
    grid on;
end

% 
% %% 
% 
% % Example parameters
% Filtering = 'iir';
% order = 4;
% method = 'butter'; % Should normalize to 'butterworth'
% filterType = 'low';
% cutoffFreq = 300; % Hz
% fs = 1000; % Hz
% 
% % Design filter and get combined plot
% [b, a, combinedPlot] = designFilter(Filtering, order, method, filterType, cutoffFreq, fs);
% 
% % Save the combined figure
% saveas(combinedPlot, 'FilterAnalysisCombined.png');
