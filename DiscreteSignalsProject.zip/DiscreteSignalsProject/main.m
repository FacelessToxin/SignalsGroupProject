%%  Defining the Spec File
%       To make it easier in case you have a new spec file, the first thing
%       (so you only have to change this one thing if necessary) is
%       changing the target spec file:

spec_file = 'global_specs_final_E24.txt';

%% Adding A path
%       A benefit of matlab is apparently we only need to add a path to be
%       able to call the functions, so secondly, we dive into all of our
%       functions:

addpath('Functions');

%% Reading the Spec File
%       First step is reading the given spec file, this will save a lot of
%       computations down the line, so therefore we read and save all the
%       parameters first:

specs_list = readspecs(spec_file);

%% The individual parameters are also saved, this is to make things easier,
% but also because unlike other programming languages, converting text to
% numbers can be hard :(

input_or_generated = specs_list{1};
WAV_filename = specs_list{2};

% Hotfix to not consider the WAV_file if its supposed to generate a digital
% signal. Very lazy, not demure.
if strcmp(input_or_generated, 'generate')
    WAV_filename = '';
end

Target_Frequency = str2double(specs_list{3});
Signal_Type = specs_list{4};
Sampling_Frequency = str2double(specs_list{5});
Signal_Duration = str2double(specs_list{6});
Periodicity = str2double(specs_list{7});
Frequencies = str2num(specs_list{8});
Spectral_Resolution = str2double(specs_list{9});
Window_Type = specs_list{10};
Overlap = str2double(specs_list{11});
Filtering = specs_list{12};
Filter_Order = str2double(specs_list{13});
Approximator = specs_list{14};
Type = specs_list{15};
Cut_Off = str2num(specs_list{16});

% Filter Hotfix
if strcmp(Type, 'lp')
    Type = 'low';
elseif strcmp(Type, 'hp')
    Type = 'high';
elseif strcmp(Type, 'bp')
    Type = 'bandpass';
elseif strcmp(Type, 'bs')
    Type = 'stop';
else
    error('Invalid Type: Expected one of ''lp'', ''hp'', ''bp'', ''bs''.');
end

Plot_Xlim = str2double(specs_list{17});
Plot_Ylim = str2double(specs_list{18});
Plot_X_Log = specs_list{19};
Plot_Y_Log = specs_list{20};
Plot_Xlim2 = specs_list{21};
Plot_Ylim2 = str2double(specs_list{22});

%% Signal Generation
% Next step of the way is turning whatever we want into a signal, for this
% we have created a dynamic function that will take inputs and dynamically
% check whether we want to read a .WAV file or generate a digital signal:

[signal, fs] = ProcessAudio(WAV_filename,Target_Frequency,Signal_Type,Sampling_Frequency,Signal_Duration,Periodicity,Frequencies); 
%(Wav_filename, {type, fs, duration, periodicity, frequencies})

%% Frequency Analysis
%       After we have created the signal, we want to provide you with a
%       plot of the signal. This way you can see the signal BEFORE a filter
%       is applied, and in case you get an urgent necessity

FrequencyAnalysis(signal,fs,Spectral_Resolution,Window_Type,Overlap,Plot_X_Log,Plot_Y_Log);
%(signal, fs, spectralResolution, windowType, overlap)

%% Filtering
%       This next section is about firstly creating a filter, and secondly
%       applying the filter to the given signal. Firstly we will design a
%       filter using the given parameters. This feature has an implemented
%       anti-aliasing element, that keeps the cut_off from exceeding the
%       frequency

% Before starting creating the filters, check for aliasing to prevent
% potential issues

Cut_Off = checkAliasing(fs, Cut_Off);

[b,a] = designFilter(Filtering,Filter_Order,Approximator,Type,Cut_Off,fs,Window_Type);
%Filtering, order, method, filterType, cutoffFreq, fs

%       Using the filter coefficients found from the filter designer, we
%       now convolve the filter unto our given signal

filtered_signal = ApplyFilter(b,a,signal);

%% Frequency analysis post-processing
%       To make sure the filtering has had the intended effect, we have
%       decide to include a post-processing frequency analysis, this serves
%       primarily to see if the filter has had the intended effect.
%       (Assuming any decision were made taking the fourier domain into
%       consideration)

FrequencyAnalysis(filtered_signal,fs,Spectral_Resolution,Window_Type,Overlap,Plot_X_Log,Plot_Y_Log);

%% Reviewing the outputs
% After reviewing the results, it might be of interest to take a look at
% the output signal and the coefficients, for that reason, the following
% section has been provided, which saves the input signal, output signal
% and the filter coefficients given:

% Saving the signal
writematrix(signal, 'input.csv');
writematrix(filtered_signal, 'output.csv');

% Saving the filters
writematrix(a,'denominators.csv')
writematrix(b,'numenators.csv')

% Saving the image
% We had issues getting it to work, so we grabbed screenshots of each
% image.