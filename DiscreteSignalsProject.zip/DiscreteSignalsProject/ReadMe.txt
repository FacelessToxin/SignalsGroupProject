Hello Dear User, thank you for downloading our function.

This readme file has been designed to help you with navigating the main.m document provided, which needs to be run for the the function to work.
That said, you are free to modify and change all of the given code, just make sure to also provide a cool ReadMe file - Pass down the things that work!

The ReadMe has been split into 2 sections. The first sections is a short description of how to use the main file
    The second section is talking a little bit about the 'functions', you can see this as a background info on how we have set up the depository!

Section 0: Necessary packages.

    To our awareness, we have purely used the online version of matlab, for this reason, we are of the opinion
    That no external packages are needed. If necessary, please upload the depository to a 'matlab.mathworks.com'
    To have the code run as ours did.

Section 1: Using The Main

    (A hotfix mention should be added. During our work, we had issues making a regular matlab script work, for that reason main2.mlx has been created
    This livescript version of the main (a direct copy paste) does not have some weird issues tha the original main script did. 
    In addition to that, we have added a "final_results" folder, with the output from the main, signals, coefficients and plots)

    When using the main, we have tried to make sure that it is as simple and as intuitive as possible, do please read the included comments
    For this reason I have 2 proposed methods of using the code, step 1 is going directly into the Main and changing what 'spec' file you're using.
    The default spec file has been set to 'global_specs_final_E24.txt', seeing as this was our final test of our function!

        The spec file covers 21 perameters that need to be filled in. It is important that none of the parameters are left empty, even if unused
        This is a shortcoming on our part, that could potentially be fixed, so feel free to go ahead if you want to leave your touch!
        In case you want to use a .wav file for the signal, do make sure to upload the appropriate .wav file, change the name in the readme AND the fs

Section 2: About the function

    During our slow and tenacious programming, we made use of a lot of different livescripts, (as of writing these, they have been saved in the folder 'OldCodeStuff'.
    Each of the individual functions called upon in the main document, has been put into the 'functions' folder. In the main documentation, you will find brief
    Commenting about the individual functions and the most necessary knowledge for it to function (in case you want to modify it, or something, against our best wishes, should be messed up)
    However for more specific documentation on the individual functions and how every step is gone about, do feel free to read the functions documentation, and reading it.